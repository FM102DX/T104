﻿namespace FerryData.Engine.Enums
{
    public enum WorkflowActionKinds
    {
        Undefined = 0,
        HttpConnector = 1,
        Sleep = 2,
    }
}
