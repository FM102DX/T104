﻿namespace FerryData.Engine.Enums
{
    public enum HttpMethods
    {
        Get = 0,
        Post = 1
    }
}
