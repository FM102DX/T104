﻿namespace FerryData.Engine.Enums
{
    public enum WorkflowStepKinds
    {
        Undefined = 0,
        Action = 1
    }
}
